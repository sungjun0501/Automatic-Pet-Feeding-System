#ifndef __KEYPAD_H
#define __KEYPAD_H

#include "main.h"

// Define keypad size
#define ROW_NUM     4
#define COLUMN_NUM  4

// Keypad GPIO pin definitions
// Rows are inputs (PB12-PB15)
#define ROW1_PIN    GPIO_PIN_12
#define ROW2_PIN    GPIO_PIN_13
#define ROW3_PIN    GPIO_PIN_14
#define ROW4_PIN    GPIO_PIN_15
#define ROW_PORT    GPIOB

// Columns are outputs (PB8-PB11)
#define COL1_PIN    GPIO_PIN_8
#define COL2_PIN    GPIO_PIN_9
#define COL3_PIN    GPIO_PIN_10
#define COL4_PIN    GPIO_PIN_11
#define COL_PORT    GPIOB

// Function prototypes
void Keypad_Init(void);
char readKeypad(void);

#endif /* __KEYPAD_H */

#include "keypad.h"
#include "lcd.h"
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

// Function to read the keypad input
char readKeypad(void) {
    const char keymap[ROW_NUM][COLUMN_NUM] = {
        {'7', '8', '9', 'C'},
        {'1', '2', '3', 'A'},
        {'4', '5', '6', 'B'},
        {'*', '0', '#', 'D'}
    };

    // Make all columns outputs and set them high
    for (uint8_t c = 0; c < COLUMN_NUM; c++) {
        GPIO_InitTypeDef GPIO_InitStruct = {0};
        GPIO_InitStruct.Mode = GPIO_MODE_OUTPUT_PP;
        GPIO_InitStruct.Pull = GPIO_NOPULL;
        GPIO_InitStruct.Speed = GPIO_SPEED_FREQ_HIGH;

        switch(c) {
            case 0: GPIO_InitStruct.Pin = COL1_PIN; break;
            case 1: GPIO_InitStruct.Pin = COL2_PIN; break;
            case 2: GPIO_InitStruct.Pin = COL3_PIN; break;
            case 3: GPIO_InitStruct.Pin = COL4_PIN; break;
        }

        HAL_GPIO_Init(COL_PORT, &GPIO_InitStruct);
        HAL_GPIO_WritePin(COL_PORT, GPIO_InitStruct.Pin, GPIO_PIN_SET);
    }

    // Make all rows inputs with pull-up resistors
    for (uint8_t r = 0; r < ROW_NUM; r++) {
        GPIO_InitTypeDef GPIO_InitStruct = {0};
        GPIO_InitStruct.Mode = GPIO_MODE_INPUT;
        GPIO_InitStruct.Pull = GPIO_PULLUP;

        switch(r) {
            case 0: GPIO_InitStruct.Pin = ROW1_PIN; break;
            case 1: GPIO_InitStruct.Pin = ROW2_PIN; break;
            case 2: GPIO_InitStruct.Pin = ROW3_PIN; break;
            case 3: GPIO_InitStruct.Pin = ROW4_PIN; break;
        }

        HAL_GPIO_Init(ROW_PORT, &GPIO_InitStruct);
    }

    // Scan the keypad
    for (uint8_t c = 0; c < COLUMN_NUM; c++) {
        uint16_t col_pin;
        switch(c) {
            case 0: col_pin = COL1_PIN; break;
            case 1: col_pin = COL2_PIN; break;
            case 2: col_pin = COL3_PIN; break;
            case 3: col_pin = COL4_PIN; break;
            default: col_pin = 0; break;
        }

        // Set the current column low
        HAL_GPIO_WritePin(COL_PORT, col_pin, GPIO_PIN_RESET);

        // Check each row
        for (uint8_t r = 0; r < ROW_NUM; r++) {
            uint16_t row_pin;
            switch(r) {
                case 0: row_pin = ROW1_PIN; break;
                case 1: row_pin = ROW2_PIN; break;
                case 2: row_pin = ROW3_PIN; break;
                case 3: row_pin = ROW4_PIN; break;
                default: row_pin = 0; break;
            }

            // If the row is low, a key is pressed
            if (HAL_GPIO_ReadPin(ROW_PORT, row_pin) == GPIO_PIN_RESET) {
                // Set the column back high
                HAL_GPIO_WritePin(COL_PORT, col_pin, GPIO_PIN_SET);

                // Debounce
                HAL_Delay(50);

                // Return the key
                return keymap[r][c];
            }
        }

        // Set the column back high
        HAL_GPIO_WritePin(COL_PORT, col_pin, GPIO_PIN_SET);
    }

    // No key pressed
    return 0;
}

// Function to initialize the keypad pins
void Keypad_Init(void) {
    GPIO_InitTypeDef GPIO_InitStruct = {0};

    // Configure keypad rows as input with pull-up
    GPIO_InitStruct.Pin = ROW1_PIN | ROW2_PIN | ROW3_PIN | ROW4_PIN;
    GPIO_InitStruct.Mode = GPIO_MODE_INPUT;
    GPIO_InitStruct.Pull = GPIO_PULLUP;
    HAL_GPIO_Init(ROW_PORT, &GPIO_InitStruct);

    // Configure keypad columns as output
    GPIO_InitStruct.Pin = COL1_PIN | COL2_PIN | COL3_PIN | COL4_PIN;
    GPIO_InitStruct.Mode = GPIO_MODE_OUTPUT_PP;
    GPIO_InitStruct.Pull = GPIO_NOPULL;
    GPIO_InitStruct.Speed = GPIO_SPEED_FREQ_HIGH;
    HAL_GPIO_Init(COL_PORT, &GPIO_InitStruct);

    // Initialize all columns to high
    HAL_GPIO_WritePin(COL_PORT, COL1_PIN | COL2_PIN | COL3_PIN | COL4_PIN, GPIO_PIN_SET);
}

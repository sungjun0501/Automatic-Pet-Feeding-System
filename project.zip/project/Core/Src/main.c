/* USER CODE BEGIN Header */
/**
  ******************************************************************************
  * @file           : main.c
  * @brief          : Main program body
  ******************************************************************************
  * @attention
  *
  * Copyright (c) 2025 STMicroelectronics.
  * All rights reserved.
  *
  * This software is licensed under terms that can be found in the LICENSE file
  * in the root directory of this software component.
  * If no LICENSE file comes with this software, it is provided AS-IS.
  *
  ******************************************************************************
  */
/* USER CODE END Header */
/* Includes ------------------------------------------------------------------*/
#include "main.h"

/* Private includes ----------------------------------------------------------*/
/* USER CODE BEGIN Includes */
#include "lcd.h"
#include "stm32f1xx_it.h"
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <math.h>

/* USER CODE END Includes */

/* Private typedef -----------------------------------------------------------*/
/* USER CODE BEGIN PTD */
// Input modes
typedef enum {
    MODE_NONE,
    MODE_WATER_LEVEL,    // A - Display water level
    MODE_TIME_INPUT,     // B - Set time
    MODE_WEIGHT_INPUT    // C - Input dog weight
} InputMode_t;

// Dog sizes for food dispensing
typedef enum {
    DOG_SIZE_SMALL,      // Small dog (< 10kg)
    DOG_SIZE_MEDIUM,     // Medium dog (10-25kg)
    DOG_SIZE_LARGE       // Large dog (> 25kg)
} DogSize_t;

char time[30]; //RTC
RTC_TimeTypeDef sTime; //RTC
/* USER CODE END PTD */

/* Private define ------------------------------------------------------------*/
/* USER CODE BEGIN PD */
// Keypad row and column pins
#define ROW_NUM     4
#define COLUMN_NUM  4

// Display mode constants
#define DISPLAY_SETTINGS 0
#define DISPLAY_GRAPH_1  1
#define DISPLAY_GRAPH_2  2

// Keypad GPIO pin definitions
// Rows are inputs (PB12-PB15)
#define ROW1_PIN    GPIO_PIN_12
#define ROW2_PIN    GPIO_PIN_13
#define ROW3_PIN    GPIO_PIN_14
#define ROW4_PIN    GPIO_PIN_15
#define ROW_PORT    GPIOB

// Columns are outputs (PB8-PB11)
#define COL1_PIN    GPIO_PIN_8
#define COL2_PIN    GPIO_PIN_9
#define COL3_PIN    GPIO_PIN_10
#define COL4_PIN    GPIO_PIN_11
#define COL_PORT    GPIOB



/* USER CODE END PD */

/* Private macro -------------------------------------------------------------*/
/* USER CODE BEGIN PM */

/* USER CODE END PM */

/* Private variables ---------------------------------------------------------*/
 RTC_HandleTypeDef hrtc;

TIM_HandleTypeDef htim1;
TIM_HandleTypeDef htim2;
TIM_HandleTypeDef htim8;

UART_HandleTypeDef huart1;

SRAM_HandleTypeDef hsram1;

/* USER CODE BEGIN PV */
   // Arrays to store food data for 5 days
   uint16_t total_food[5] = {0, 0, 0, 0, 0};    // Total food served
   uint16_t consumed_food[5] = {0, 0, 0, 0, 0};  // Example values
   uint16_t leftover_food[5] = {0, 0, 0, 0, 0};
   uint16_t eating_time_array[5] = {0, 0, 0, 0, 0};   // Time taken to eat (minutes)

   uint16_t total_food_detail[3] = {0, 0, 0};    // Total food served
   uint16_t consumed_food_detail[3] = {0, 0, 0};  // Example values
   uint16_t leftover_food_detail[3] = {0, 0, 0};
   uint16_t eating_time_array_detail[3] = {0, 0, 0};
   // Display mode tracking
   uint8_t display_mode = 0; // 0=settings, 1=graph1, 2=graph2

   // Current day data tracking
   uint16_t current_day_total = 0;      // Current day's total food
   uint16_t current_day_consumed = 0;   // Current day's consumed food
   uint16_t current_day_eating_time = 0;// Current day's eating time

   // Time tracking
   uint8_t current_day = 1;    // Current day (1-31)
   uint8_t current_hour = 0;   // Current hour (0-23)
   uint8_t current_minute = 0; // Current minute (0-59)
   uint8_t current_second = 0; // Current second (0-59) - ADDED THIS LINE
   uint8_t previous_day = 1;   // To detect day change
   uint8_t data_updated_today = 0; // Flag to prevent multiple updates
   uint8_t current_day_index = 0;  // Index for the circular buffer
   uint8_t current_day_index_detail = 0;
   uint8_t time_has_been_set = 0;  // Flag to indicate if time has been set - ADDED THIS LINE

   // Keypad variables
   uint8_t current_key_index = 0; // Current input buffer index
   char key_buffer[5] = {0};      // Buffer to store keypad input (max 4 digits + null)
   uint8_t active_function = 0;   // Current active function (0=none, 1=A:time, 2=B:delay, 3=C:amount)

   // Food dispensing settings
   uint16_t dispense_time[3] = {0, 1200, 1800}; // Default dispense times (8:30am, 12:30pm, 6:30pm)
   uint16_t dispense_delay = 240;                 // Default delay between dispenses (in minutes)
   uint16_t dispense_amount = 100;                // Default amount to dispense (in grams)

   // Time display variables
   char time_buffer[32]; // Increased buffer size
   uint8_t last_displayed_minute = 0xFF; // To track when to update the display

   // State for keypad input handling
   InputMode_t current_mode = MODE_NONE;
   uint8_t container_height=20;// height of container in cm
   int water_level=0;              // Default water level 0%
   int food_level=0;               // Default food level 0%
   uint16_t dog_weight = 0;               // Dog weight in kg
   DogSize_t dog_size = DOG_SIZE_MEDIUM;  // Default to medium dog

   // Updated values for food dispensing based on dog size (these are backup defaults)
   const uint16_t FOOD_AMOUNT_SMALL = 50;   // 50g for small dogs
   const uint16_t FOOD_AMOUNT_MEDIUM = 150; // 150g for medium dogs
   const uint16_t FOOD_AMOUNT_LARGE = 350;  // 350g for large dogs
   const uint8_t DISPENSE_SPEED_SMALL = 2;  // Slower speed for small dogs
   const uint8_t DISPENSE_SPEED_MEDIUM = 3; // Medium speed
   const uint8_t DISPENSE_SPEED_LARGE = 5;  // Faster speed for large dogs

   // Food calorie density (kcal per kg)
   const uint16_t FOOD_CALORIE_DENSITY = 1000; // 1000 kcal per kg (1 kcal per gram)

   // Current dispense parameters
   int food_amount = 211;            // Amount of food to dispense (g)
   int food_amount_ideal=211;
   uint8_t dispense_speed = 3;            // Dispensing speed (1-5)

	#define TRIG_PIN_WATER GPIO_PIN_12	// (us sensor)  output
	#define TRIG_PORT_WATER GPIOC		// (us sensor)
	#define ECHO_PIN_WATER GPIO_PIN_9 	// (us sensor)  input
	#define ECHO_PORT_WATER GPIOC		// (us sensor)
	uint32_t pMillis_WATER;				// (us sensor)
	uint32_t Value1_WATER = 0;			// (us sensor)
	uint32_t Value2_WATER = 0;			// (us sensor)
	float Distance_WATER  ;  		// (us sensor) cm

	#define TRIG_PIN_FOOD GPIO_PIN_7	// (us sensor)  output
	#define TRIG_PORT_FOOD GPIOC		// (us sensor)
	#define ECHO_PIN_FOOD GPIO_PIN_11 	// (us sensor)  input
	#define ECHO_PORT_FOOD GPIOC		// (us sensor)
	uint32_t pMillis_FOOD;				// (us sensor)
	uint32_t Value1_FOOD = 0;			// (us sensor)
	uint32_t Value2_FOOD = 0;			// (us sensor)
	float Distance_FOOD  ;  		// (us sensor) cm



	#define DT_PIN GPIO_PIN_2//(load) INPUT
	#define DT_PORT GPIOA//(load)
	#define SCK_PIN GPIO_PIN_11//(load) OUTPUT
	#define SCK_PORT GPIOA//(load)
	uint32_t tare = 8453700; //load
	float knownOriginal = 120;  // in milli gram
	float knownHX711 = 40790;//load
	int weight;//(load)

	#define DT_PIN_RIGHT GPIO_PIN_6//(load) INPUT
	#define DT_PORT_RIGHT GPIOB//(load)
	#define SCK_PIN_RIGHT GPIO_PIN_7//(load) OUTPUT
	#define SCK_PORT_RIGHT GPIOB//(load)
	uint32_t tare_RIGHT = 8453700; //load
	float knownOriginal_RIGHT = 120;  // in milli gram
	float knownHX711_RIGHT = 40790;//load
	int weight_RIGHT;//(load)


	#define NUM_SAMPLES 20					// load
	int32_t hx711_buffer[NUM_SAMPLES] = {0};
	uint8_t hx711_index = 0;
	int64_t hx711_sum = 0;

	#define NO_CHANGE_THRESHOLD_MS 60000  // CHECK eating done?
	#define MIN_WEIGHT_DELTA 10           // if more than # gram changes eating not done

	#define DIR_PIN GPIO_PIN_4		//(NEMA 17)		GREEN
	#define DIR_PORT GPIOC			//(NEMA 17)
	#define STEP_PIN GPIO_PIN_7		//(NEMA 17)			BLUE
	#define STEP_PORT GPIOA			//(NEMA 17)

	#define DIR_PIN_T GPIO_PIN_3		//(NEMA 17)		GREEN
	#define DIR_PORT_T GPIOC			//(NEMA 17)
	#define STEP_PIN_T GPIO_PIN_3	//(NEMA 17)			BLUE
	#define STEP_PORT_T GPIOD			//(NEMA 17)

	  int leftoverstate=0; 	//checking leftover'
	  uint8_t rxData;
	  char receiveMsg[10];


/* USER CODE END PV */

/* Private function prototypes -----------------------------------------------*/
void SystemClock_Config(void);
static void MX_GPIO_Init(void);
static void MX_FSMC_Init(void);
static void MX_TIM1_Init(void);
static void MX_TIM2_Init(void);
static void MX_TIM8_Init(void);
static void MX_RTC_Init(void);
static void MX_USART1_UART_Init(void);
/* USER CODE BEGIN PFP */

/* USER CODE END PFP */

/* Private user code ---------------------------------------------------------*/
/* USER CODE BEGIN 0 */

uint16_t calculateYAxisMax(uint16_t inputValue) {
    // If value is already divisible by 50, use it as is
    if (inputValue % 50 == 0) {
        return inputValue;
    }

    // Otherwise, round up to the nearest value divisible by 50
    return ((inputValue + 49) / 50) * 50;
}

uint16_t find_max(uint16_t arr1[], uint16_t arr2[], uint16_t size) {
    uint16_t max_value = 0;  //  ??????????????????? 번째 값을 초기 최댓값으 ??????????????????? ?  ?

    for (uint16_t i = 0; i < size; i++) {
       arr2[i] = total_food[i] - consumed_food[i];  } //example value

    for (uint16_t i = 0; i < size; i++) {
        if (arr1[i] > max_value) {
            max_value = arr1[i];  // ?   ?   값이 ?  ?   ??????????????????? 갱신
        }
        if (arr2[i] > max_value){
           max_value = arr2[i];  // ?   ?   값이 ?  ?   ??????????????????? 갱신
        }
    }
    return max_value;
}

void drawYAxisLabels(uint16_t maxValue) {
    // We always want 10 portions (11 labels including 0)
    const uint8_t NUM_PORTIONS = 10;
    uint16_t portion = maxValue / NUM_PORTIONS;
    char buffer[8];

    // Calculate the pixel height of each portion
    float pixelHeight = 230.0 / NUM_PORTIONS; // 230 pixels from y=20 to y=250

    // Draw the main labels (0, portion, 2*portion, ..., maxValue)
    for (int i = 0; i <= NUM_PORTIONS; i++) {
        uint16_t value = i * portion;
        uint16_t yPos = 250 - (i * pixelHeight);

        // Format the value
        sprintf(buffer, "%d", value);


        // Adjust x position based on number of digits for better alignment
        int xPos = 0;
        if (value < 10) {
            xPos = 14;  // Single digit
        } else if (value < 100) {
            xPos = 8;   // Double digit
        } else if (value < 1000) {
            xPos = 2;   // Triple digit
        } else {
            xPos = 0;   // Four digits or more
        }

        LCD_DrawSmallString(xPos, yPos - 4, buffer); // -4 to center text vertically

        // Draw main tick mark
        LCD_DrawLine(28, yPos, 32, yPos, BLACK);

        // Draw midpoint tick mark (if not the last main tick)
        if (i < NUM_PORTIONS) {
            uint16_t midYPos = yPos - (pixelHeight / 2);
            LCD_DrawLine(28, midYPos, 31, midYPos, BLACK); // Slightly shorter tick for midpoint
        }
    }
}

void draw_graph_1(){

   // ###1 Draw Axis
    LCD_DrawLine ( 30, 20, 30, 250, BLACK); // Y axis
    LCD_DrawLine ( 30, 20, 26, 24, BLACK); // Y Arrow - left
    LCD_DrawLine ( 30, 20, 34, 24, BLACK); // Y Arrow - right

    LCD_DrawLine ( 30, 250, 230, 250, BLACK); // X axis
    LCD_DrawLine ( 230, 250, 226, 246, BLACK); // X Arrow - up
    LCD_DrawLine ( 230, 250, 226, 254, BLACK); // X Arrow - down


   // ###2 Write String
    LCD_DrawString ( 15, 0, "Consumed / Leftover Weight"); // Title at top

    LCD_DrawString ( 11, 288, "Consumed(g)");                // Description at bottom #1
    LCD_Clear ( 1, 290, 9, 9, RED );                   // Red Square
    LCD_DrawString ( 11, 304, "Leftover(g)");                // Description at bottom #2
    LCD_Clear ( 1, 306, 9, 9, BLUE );                   // Blue Square


   /* ###3 Label
      x axis label */
    LCD_DrawSmallString(40, 255, "D-4");
    LCD_DrawSmallString(80, 255, "D-3");
    LCD_DrawSmallString(120, 255, "D-2");
    LCD_DrawSmallString(160, 255, "D-1");
    LCD_DrawSmallString(200, 255, "Today");

     // y axis Label
    uint16_t max_value = find_max(consumed_food, leftover_food, 5);      // find biggest number in 'total_food' array
     uint16_t yAxisMax = calculateYAxisMax(max_value);   // Calculate Y-axis scale based on user input
     drawYAxisLabels(yAxisMax);                    // Draw the y-axis with calculated max value


   // ###4 Draw Boxes
   /* graph size: 200 (x) by 230 (y)
     graph range 30~230(x) by 20~250 (y)
     width per day = 40 pixel*/

   int graph_Y_cord = 250;   // y coordinate of y axis
   int box_width = 10; // width of boxes on graph

   int R = 200; // starting x coordinate of Red box
   int B = 210; // starting x coordinate of Blue box
   int instant=0;

   for (uint16_t i = 0; i < 5; i++) {
      uint16_t leftover_food1 = total_food[4-i] - consumed_food[4-i];   //example value

      int consumed_box_height = (consumed_food[4-i] * 230 / yAxisMax) ;   // box height from grams to pixels  (**don't change calculation order )
      int leftover_box_height = (leftover_food1 * 230 / yAxisMax) ;

      if (total_food[4-i]==0){instant++;}
      else{
      LCD_Clear ( R-40*i+40*instant, (graph_Y_cord - consumed_box_height), box_width, consumed_box_height, RED );                   // consumed
      LCD_Clear ( B-40*i+40*instant, (graph_Y_cord - leftover_box_height), box_width, leftover_box_height, BLUE );                  // leftover
      }
   }


}

void microDelay(uint16_t delay)//(load, NEMA)
{
  __HAL_TIM_SET_COUNTER(&htim1, 0);
  while (__HAL_TIM_GET_COUNTER(&htim1) < delay);
}

void step (int steps, uint8_t direction, uint16_t delay) //(NEMA17)
{
  int x;
  if (direction == 0)
    HAL_GPIO_WritePin(DIR_PORT, DIR_PIN, GPIO_PIN_SET);
  else
    HAL_GPIO_WritePin(DIR_PORT, DIR_PIN, GPIO_PIN_RESET);
  for(x=0; x<steps; x=x+1)
  {
    HAL_GPIO_WritePin(STEP_PORT, STEP_PIN, GPIO_PIN_SET);
    microDelay(delay);
    HAL_GPIO_WritePin(STEP_PORT, STEP_PIN, GPIO_PIN_RESET);
    microDelay(delay);
  }
}

void step_T (int steps, uint8_t direction, uint16_t delay) //(NEMA17)
{
  int x;
  if (direction == 0)
    HAL_GPIO_WritePin(DIR_PORT_T, DIR_PIN_T, GPIO_PIN_SET);
  else
    HAL_GPIO_WritePin(DIR_PORT_T, DIR_PIN_T, GPIO_PIN_RESET);
  for(x=0; x<steps; x=x+1)
  {
    HAL_GPIO_WritePin(STEP_PORT_T, STEP_PIN_T, GPIO_PIN_SET);
    microDelay(delay);
    HAL_GPIO_WritePin(STEP_PORT_T, STEP_PIN_T, GPIO_PIN_RESET);
    microDelay(delay);
  }
}

int32_t getHX711(void)//(load)
{
  uint32_t data = 0;
  uint32_t startTime = HAL_GetTick();
  while(HAL_GPIO_ReadPin(DT_PORT, DT_PIN) == GPIO_PIN_SET)
  {
    if(HAL_GetTick() - startTime > 200)
      return 0;
  }
  for(int8_t len=0; len<24 ; len++)
  {
    HAL_GPIO_WritePin(SCK_PORT, SCK_PIN, GPIO_PIN_SET);
    microDelay(1);
    data = data << 1;
    HAL_GPIO_WritePin(SCK_PORT, SCK_PIN, GPIO_PIN_RESET);
    microDelay(1);
    if(HAL_GPIO_ReadPin(DT_PORT, DT_PIN) == GPIO_PIN_SET)
      data ++;
  }
  data = data ^ 0x800000;
  HAL_GPIO_WritePin(SCK_PORT, SCK_PIN, GPIO_PIN_SET);
  microDelay(1);
  HAL_GPIO_WritePin(SCK_PORT, SCK_PIN, GPIO_PIN_RESET);
  microDelay(1);
  return data;
}

int32_t getHX711_RIGHT(void)//(load)
{
  uint32_t data = 0;
  uint32_t startTime = HAL_GetTick();
  while(HAL_GPIO_ReadPin(DT_PORT_RIGHT, DT_PIN_RIGHT) == GPIO_PIN_SET)
  {
    if(HAL_GetTick() - startTime > 200)
      return 0;
  }
  for(int8_t len=0; len<24 ; len++)
  {
    HAL_GPIO_WritePin(SCK_PORT_RIGHT, SCK_PIN_RIGHT, GPIO_PIN_SET);
    microDelay(1);
    data = data << 1;
    HAL_GPIO_WritePin(SCK_PORT_RIGHT, SCK_PIN_RIGHT, GPIO_PIN_RESET);
    microDelay(1);
    if(HAL_GPIO_ReadPin(DT_PORT_RIGHT, DT_PIN_RIGHT) == GPIO_PIN_SET)
      data ++;
  }
  data = data ^ 0x800000;
  HAL_GPIO_WritePin(SCK_PORT_RIGHT, SCK_PIN_RIGHT, GPIO_PIN_SET);
  microDelay(1);
  HAL_GPIO_WritePin(SCK_PORT_RIGHT, SCK_PIN_RIGHT, GPIO_PIN_RESET);
  microDelay(1);
  return data;
}

int weigh(void) { //load

    int32_t new_sample = getHX711();

    // ?  ?  ?    ????????????? ?   ?????????????, ?   ?  ?   �???? ?
    hx711_sum -= hx711_buffer[hx711_index];
    hx711_buffer[hx711_index] = new_sample;
    hx711_sum += new_sample;

    // ?  ?  ?   ?  ?
    hx711_index = (hx711_index + 1) % NUM_SAMPLES;

    // ?   ????????????? 계산
    int32_t average = hx711_sum / NUM_SAMPLES;

    float coefficient = knownOriginal / knownHX711;
    int milligram = (int)((average - tare) * coefficient);

    char str[32];
    sprintf(str, "weight_L: %10d g", milligram);
    //LCD_DrawString(30, 200, str);
    return milligram;
}

int weigh_RIGHT(void) { //load

    int32_t new_sample = getHX711_RIGHT();

    // ?  ?  ?    ????????????? ?   ?????????????, ?   ?  ?   �???? ?
    hx711_sum -= hx711_buffer[hx711_index];
    hx711_buffer[hx711_index] = new_sample;
    hx711_sum += new_sample;

    // ?  ?  ?   ?  ?
    hx711_index = (hx711_index + 1) % NUM_SAMPLES;

    // ?   ????????????? 계산
    int32_t average = hx711_sum / NUM_SAMPLES;

    float coefficient = knownOriginal_RIGHT / knownHX711_RIGHT;
    int milligram_right = (int)((average - tare_RIGHT) * coefficient);

    char str[32];
    sprintf(str, "weight_R: %10d g", milligram_right);
    //debug LCD_DrawString(30, 220, str);
    return milligram_right;
}

int checkWeightStability(dispense_time_number, current_time) {
    static int last_weight = 0;
    static uint32_t last_change_time = 0;

    int current_weight = weigh();  // ?  ?   무게 측정
    uint32_t now = HAL_GetTick();

    // 무게  ??????????????   �???? ?
    if (abs(current_weight - last_weight) > MIN_WEIGHT_DELTA) {
        last_change_time = now;            // �???? ? ?????????????  ??????????????   ?   ????????????? 갱신
        last_weight = current_weight;      // left over food
    }

    if (now - last_change_time > NO_CHANGE_THRESHOLD_MS) {
    	int consumedfood = food_amount-current_weight;
    	int eatingtime = dispense_time_number - current_time;
    	addFoodRecord_detail(food_amount, consumedfood, eatingtime);

    	//below is for DEBUG purpose
      	char weigt1[20];
	    sprintf(weigt1, "leftover: %9d g", current_weight);
	    //LCD_DrawString(0, 300, weigt1);

	    HAL_Delay(50);
        //LCD_DrawString(0, 120, "Weight stable for 1 min!");
        last_change_time = now;
        __HAL_TIM_SET_COMPARE(&htim8, TIM_CHANNEL_1, 500);
        return 1;
    }
    return 0;
}



float UltraSonic_Sensor_WATER()
{
	  HAL_GPIO_WritePin(TRIG_PORT_WATER, TRIG_PIN_WATER, GPIO_PIN_SET);  // pull the TRIG pin HIGH
	  __HAL_TIM_SET_COUNTER(&htim1, 0);
	  while (__HAL_TIM_GET_COUNTER (&htim1) < 10);  // wait for 10 us
	  HAL_GPIO_WritePin(TRIG_PORT_WATER, TRIG_PIN_WATER, GPIO_PIN_RESET);  // pull the TRIG pin low

	  pMillis_WATER = HAL_GetTick(); // used this to avoid infinite while loop  (for timeout)
	  // wait for the echo pin to go high
	  while (!(HAL_GPIO_ReadPin (ECHO_PORT_WATER, ECHO_PIN_WATER)) && pMillis_WATER + 10 >  HAL_GetTick());
	  Value1_WATER = __HAL_TIM_GET_COUNTER (&htim1);

	  pMillis_WATER = HAL_GetTick(); // used this to avoid infinite while loop (for timeout)
	  // wait for the echo pin to go low
	  while ((HAL_GPIO_ReadPin (ECHO_PORT_WATER, ECHO_PIN_WATER)) && pMillis_WATER + 50 > HAL_GetTick());
	  Value2_WATER = __HAL_TIM_GET_COUNTER (&htim1);

	  if (Value2_WATER > Value1_WATER) {
		  Distance_WATER = (Value2_WATER - Value1_WATER) * 0.034 / 2;
	      }
	  else {
	          Distance_WATER = 0;
	      }
	      HAL_Delay(5);

	      	char US_Sensor[20];
		    sprintf(US_Sensor, "Dist:W %9d cm", Distance_WATER);
		    //debug LCD_DrawString(0, 0, US_Sensor);
	return Distance_WATER;
}

float UltraSonic_Sensor_FOOD()
{
	  HAL_GPIO_WritePin(TRIG_PORT_FOOD, TRIG_PIN_FOOD, GPIO_PIN_SET);  // pull the TRIG pin HIGH
	  __HAL_TIM_SET_COUNTER(&htim1, 0);
	  while (__HAL_TIM_GET_COUNTER (&htim1) < 10);  // wait for 10 us
	  HAL_GPIO_WritePin(TRIG_PORT_FOOD, TRIG_PIN_FOOD, GPIO_PIN_RESET);  // pull the TRIG pin low

	  pMillis_FOOD = HAL_GetTick(); // used this to avoid infinite while loop  (for timeout)
	  // wait for the echo pin to go high
	  while (!(HAL_GPIO_ReadPin (ECHO_PORT_FOOD, ECHO_PIN_FOOD)) && pMillis_FOOD + 10 >  HAL_GetTick());
	  Value1_FOOD = __HAL_TIM_GET_COUNTER (&htim1);

	  pMillis_FOOD = HAL_GetTick(); // used this to avoid infinite while loop (for timeout)
	  // wait for the echo pin to go low
	  while ((HAL_GPIO_ReadPin (ECHO_PORT_FOOD, ECHO_PIN_FOOD)) && pMillis_FOOD + 50 > HAL_GetTick());
	  Value2_FOOD = __HAL_TIM_GET_COUNTER (&htim1);

	  if (Value2_FOOD > Value1_FOOD) {
		  Distance_FOOD = (Value2_FOOD - Value1_FOOD) * 0.034 / 2;
	      }
	  else {
	          Distance_FOOD = 0;
	      }
	      HAL_Delay(5);

	      	char US_Sensor[20];
		    sprintf(US_Sensor, "Dist:F %9d cm", Distance_FOOD);
		    //debug LCD_DrawString(0, 50, US_Sensor);
	return Distance_FOOD;
}

// For smaller values like eating speed (grams/min)
uint16_t calculateSmallYAxisMax(uint16_t inputValue) {
    // If value is smaller than 5, use a min scale of 5
    if (inputValue <= 5) {
        return 5;
    }

    // For eating speed, we want a smaller scale (divisible by 5)
    if (inputValue % 5 == 0) {
        return inputValue;
    }

    // Round up to nearest value divisible by 5
    return ((inputValue + 4) / 5) * 5;
}

// Function to add a new food record
void addFoodRecord(uint16_t totalFood, uint16_t consumedFood, uint16_t eatingTime) {
    // Update the arrays with the new values
    total_food[current_day_index] = totalFood;
    consumed_food[current_day_index] = consumedFood;
    eating_time_array[current_day_index] = eatingTime;

    // Move to the next day
    current_day_index = (current_day_index + 1) % 5;
}

void addFoodRecord_detail(uint16_t totalFood, uint16_t consumedFood, uint16_t eatingTime){
     total_food_detail[current_day_index_detail] = totalFood;
     consumed_food_detail[current_day_index_detail] = consumedFood;
   eating_time_array_detail[current_day_index_detail] = eatingTime;

    // Move to the next day
    current_day_index_detail = (current_day_index_detail + 1) % 5;
    uint16_t total_food = 0;
    uint16_t consumed_food = 0;
    uint16_t eating_time = 0;

    for (int i; i<3; i++){
    	total_food = total_food+total_food_detail[i];
		consumed_food = consumed_food + consumed_food_detail[i];
		eating_time = eating_time + eating_time_array_detail[i];
    }
    if (total_food_detail[2] != 0){
    addFoodRecord(total_food/3, consumed_food/3, eating_time/3);
    for (int i; i<3; i++){
        total_food_detail[i] = 0;
        consumed_food_detail[i] = 0;
        eating_time_array_detail[i] = 0;
    }
    }
}

// Draw a line between two points (for the eating speed graph)
void draw_line_between_points(int x1, int y1, int x2, int y2, uint16_t color) {
    LCD_DrawLine(x1, y1, x2, y2, color);
}

// Fixed version of draw_graph_2 to avoid buffer overflow in speed_text
void draw_graph_2() {
    LCD_DrawLine(30, 20, 30, 250, BLACK); // Y axis
    LCD_DrawLine(30, 20, 26, 24, BLACK); // Y Arrow - left
    LCD_DrawLine(30, 20, 34, 24, BLACK); // Y Arrow - right

    LCD_DrawLine(30, 250, 230, 250, BLACK); // X axis
    LCD_DrawLine(230, 250, 226, 246, BLACK); // X Arrow - up
    LCD_DrawLine(230, 250, 226, 254, BLACK); // X Arrow - down

    LCD_DrawString(30, 0, "Consumption Speed (g/min)"); // Title at top

    // x axis
    LCD_DrawSmallString(40, 255, "D-4");
    LCD_DrawSmallString(80, 255, "D-3");
    LCD_DrawSmallString(120, 255, "D-2");
    LCD_DrawSmallString(160, 255, "D-1");
    LCD_DrawSmallString(200, 255, "Today");

    // Calculate eating speed for each day (grams/minute)
    uint16_t eating_speed[5] = {0};
    uint16_t max_speed = 0;

    for (int i = 0; i < 5; i++) {
        if (eating_time_array[i] > 0) {
            eating_speed[i] = consumed_food[i] / eating_time_array[i];
            if (eating_speed[i] > max_speed) {
                max_speed = eating_speed[i];
            }
        }
    }

    // Ensure we have at least a minimum scale
    if (max_speed < 5) max_speed = 5;

    // For eating speed, we want a different scale than the consumption graph
    uint16_t yAxisMax = calculateSmallYAxisMax(max_speed + 5); // Add margin for better visualization

    // Draw the y-axis with calculated max value
    drawYAxisLabels(yAxisMax);

    // Graph parameters
    int graph_Y_cord = 250;   // y coordinate of y axis
    int point_radius = 3;     // Radius of points in the line graph
    int x_start = 40;         // X position of first day
    int x_interval = 40;      // X interval between days

    // Coordinates for the line points
    int x_coords[5] = {0};
    int y_coords[5] = {0};
    int valid_days = 0;

    // Draw the line graph for eating speed
    for (int day = 0; day < 5; day++) {
        // Calculate which index to use from the circular buffer
        int index = (current_day_index + day) % 5;

        // Skip days with no data (eating time = 0)
       // if (eating_time_array[index] == 0) continue;

        // Calculate Y position based on eating speed
        int x_pos = x_start + day * x_interval;
        int y_pos = graph_Y_cord - (eating_speed[index] * 230 / yAxisMax);

        // Store coordinates for drawing lines
        x_coords[valid_days] = x_pos;
        y_coords[valid_days] = y_pos;
        valid_days++;

        // Draw point
        for (int i = -point_radius; i <= point_radius; i++) {
            for (int j = -point_radius; j <= point_radius; j++) {
                if (i*i + j*j <= point_radius*point_radius) {
                    LCD_DrawDot(x_pos + i, y_pos + j, BLACK);
                }
            }
        }

        // Draw speed value above the point - use larger buffer size
        char speed_text[10]; // Increased from 5 to 10
        snprintf(speed_text, sizeof(speed_text), "%d", eating_speed[index]);
        LCD_DrawSmallString(x_pos - 4, y_pos - 15, speed_text);
    }

    // Connect the points with lines
    for (int i = 0; i < valid_days - 1; i++) {
        draw_line_between_points(x_coords[i], y_coords[i], x_coords[i+1], y_coords[i+1], BLACK);
    }
}

// Modified updateTime function to handle time updating differently based on time_has_been_set
/*void updateTime(void) {
    static uint32_t last_tick = 0;
    uint32_t current_tick = HAL_GetTick();

    // Update every second (1000 ms)
    if (current_tick - last_tick >= 1000) {
        last_tick = current_tick;

        // Increment seconds
        current_second++;

        // Handle overflow
        if (current_second >= 60) {
            current_second = 0;
            current_minute++;

            if (current_minute >= 60) {
                current_minute = 0;
                current_hour++;

                if (current_hour >= 24) {
                    current_hour = 0;
                    current_day++;

                    if (current_day > 31) {
                        current_day = 1; // Simple month simulation
                    }

                    // Reset update flag for the new day
                    data_updated_today = 0;
                }
            }
        }
    }
}*/

void updateTime(void) {
    RTC_TimeTypeDef rtc_time;
    RTC_DateTypeDef rtc_date;

    // 반드?   ?  간과 ?   ????????????? ?   ?   ?  ?  ?   RTC ?   ????????????? ?  ?  ?   반영?
    HAL_RTC_GetTime(&hrtc, &rtc_time, RTC_FORMAT_BIN);
    HAL_RTC_GetDate(&hrtc, &rtc_date, RTC_FORMAT_BIN);

    // RTC ?   ?  ?    ??????????????   복사
    current_hour   = rtc_time.Hours;
    current_minute = rtc_time.Minutes;
    current_second = rtc_time.Seconds;

    // ?  루에 ?   번만 ?  ?  ?  ?   ?  ?   ?????????????  ????????????? ?????????????
    if (current_hour == 0 && current_minute == 0 && current_second == 0) {
        if (data_updated_today == 0) {
            data_updated_today = 1;
            // ?   ????????????? 1?   ?  ?  ?   ?  ?  ?   ?  ?   ????????????? ?  기에 ?  ?
        }
    }

}


/*// Check if it's time for midnight update
void checkForMidnightUpdate(void) {
    updateTime(); // Update current time

    // Check if the day has changed and if it's 00:01
    if (current_day != previous_day) {
        previous_day = current_day;

        // At 00:01, update data if not already updated today
        if (current_hour == 0 && current_minute == 1 && !data_updated_today) {
            shiftArraysAndAddNewDay();
            data_updated_today = 1; // Set flag to prevent multiple updates

            // Reset current day's data for the new day
            current_day_total = 0;
            current_day_consumed = 0;
            current_day_eating_time = 0;
        }
    }
}

// Shift arrays and add the current day's data
void shiftArraysAndAddNewDay(void) {
    // Shift all data one position
    for (int i = 0; i < 4; i++) {
        total_food[i] = total_food[i+1];
        consumed_food[i] = consumed_food[i+1];
        eating_time_array[i] = eating_time_array[i+1];
    }

    // Add current day's data to the newest position (index 4)
    total_food[4] = current_day_total;
    consumed_food[4] = current_day_consumed;
    eating_time_array[4] = current_day_eating_time;

    // Calculate leftover for all days
    for (int i = 0; i < 5; i++) {
        leftover_food[i] = total_food[i] - consumed_food[i];
    }
}*/

// Update current day's data (call this when collecting data during the day)
void updateDailyRecord(uint16_t totalFood, uint16_t consumedFood, uint16_t eatingTime) {
    current_day_total = totalFood;
    current_day_consumed = consumedFood;
    current_day_eating_time = eatingTime;
}

int FoodWeightForDog(food_amount_ideal){
    // Convert buffer to weight value
    dog_weight = atoi(key_buffer);
    float red_value = 0.0f;  // Required Energy Demand in kcal

    // Calculate RED based on dog size
    // Determine dog size with new classification
    if (dog_weight < 5) {
        dog_size = DOG_SIZE_SMALL;
        // RED = 70 * weight^0.75
        red_value = 70.0f * powf((float)dog_weight, 0.75f);
    }
    else if (dog_weight <= 45) {
        dog_size = DOG_SIZE_MEDIUM;
        // RED = 30 * weight + 70
        red_value = 30.0f * (float)dog_weight + 70.0f;
    }
    else {
        dog_size = DOG_SIZE_LARGE;
        // RED = 70 * weight^0.75
        red_value = 70.0f * powf((float)dog_weight, 0.75f);
    }

    // Calculate food amount in grams (RED / food calorie density)
    // Food energy density is 1000 kcal/kg = 1 kcal/g
    food_amount_ideal = (int)(red_value / (FOOD_CALORIE_DENSITY / 1000.0f));
    return food_amount_ideal;

}

// Updated processKeypadInput function with food calculation without displaying RED
void processKeypadInput(key) {
    // Handle * key to return to main menu from anywhere
    if (key == '*') {
        // Always return to main menu when * is pressed
        current_mode = MODE_NONE;
        active_function = 0; // Reset the active function flag
        display_mode = DISPLAY_SETTINGS;
        LCD_Clear(0, 0, 240, 320, BACKGROUND);
        show_dispense_settings();
        return;
    }

    // Handle mode selection (A, B, C keys)
    if (key == 'A') {
        current_mode = MODE_WATER_LEVEL;
        // Clear the input buffer and reset index
        memset(key_buffer, 0, sizeof(key_buffer));
        current_key_index = 0;

        // Display water level screen (read-only, no setting capability)
        displayFoodWaterLevel();

        // Reset active function
        active_function = 0;
        return;
    }
    else if (key == 'B') {
        current_mode = MODE_TIME_INPUT;
        // Clear the input buffer and reset index
        memset(key_buffer, 0, sizeof(key_buffer));
        current_key_index = 0;

        // Display time input screen
        LCD_Clear(0, 0, 240, 320, BACKGROUND);
        LCD_DrawString(20, 30, "Time Input (HHMM)");
        LCD_DrawString(20, 60, "Enter time (0000-2359):");
        LCD_DrawSmallString(20, 90, "Press # to confirm");
        LCD_DrawSmallString(20, 110, "Press D to delete");
        LCD_DrawSmallString(20, 130, "Press * to cancel");

        // Set active function for time input
        active_function = 1;
        return;
    }
    else if (key == 'C') {
        current_mode = MODE_WEIGHT_INPUT;
        // Clear the input buffer and reset index
        memset(key_buffer, 0, sizeof(key_buffer));
        current_key_index = 0;

        // Display weight input screen
        LCD_Clear(0, 0, 240, 320, BACKGROUND);
        LCD_DrawString(20, 20, "Dog Weight Input");
        LCD_DrawString(20, 50, "Enter weight (kg):");
        LCD_DrawSmallString(20, 100, "Press # to confirm");
        LCD_DrawSmallString(20, 120, "Press D to delete");
        LCD_DrawSmallString(20, 140, "Press * to cancel");
        LCD_DrawSmallString(20, 180, "Small: < 5kg");
        LCD_DrawSmallString(20, 200, "Medium: 5 ~ 45kg");
        LCD_DrawSmallString(20, 220, "Large: > 45kg");

        // Set a different active function for weight input (4 instead of 3)
        active_function = 4; // New unique value specifically for weight input
        return;
    }

    // Handle delete key (D)
    if (key == 'D') {
        // Delete last character if there's text in the buffer
        if (current_key_index > 0) {
            key_buffer[--current_key_index] = '\0';

            // Update display to show current buffer
            if (current_mode == MODE_TIME_INPUT) {
                // Clear input area
                LCD_Clear(20, 150, 200, 30, BACKGROUND);
                // Display current buffer
                LCD_DrawString(20, 150, key_buffer);
            }
            else if (current_mode == MODE_WEIGHT_INPUT) {
                // Clear input area
                LCD_Clear(20, 150, 200, 30, BACKGROUND);
                // Display current buffer
                LCD_DrawString(20, 150, key_buffer);
            }
        }
        return;
    }

    // Handle confirmation key (#)
    if (key == '#') {
        // Process the input based on current mode
        /*if (current_mode == MODE_TIME_INPUT && current_key_index > 0) {
            // Convert buffer to time value
            uint16_t time_value = atoi(key_buffer);

            // Validate time (0000-2359 format)
            uint8_t hours = time_value / 100;
            uint8_t minutes = time_value % 100;

            if (hours < 24 && minutes < 60) {
                // Valid time format - set the current time
                current_hour = hours;
                current_minute = minutes;
                current_second = 0; // Reset seconds when setting time
                time_has_been_set = 1; // Mark time as set by user

                // Display confirmation
                LCD_Clear(20, 190, 200, 30, BACKGROUND);
                char time_msg[32];
                sprintf(time_msg, "Time set: %02d:%02d:%02d", hours, minutes, 0);
                LCD_DrawString(20, 190, time_msg);

                // Clear buffer for next input
                memset(key_buffer, 0, sizeof(key_buffer));
                current_key_index = 0;

                // Wait a moment then return to main menu
                HAL_Delay(1500);
                current_mode = MODE_NONE;
                active_function = 0; // Reset active function flag
                display_mode = DISPLAY_SETTINGS;
                show_dispense_settings();
            }
            else {
                // Invalid time format
                LCD_Clear(20, 190, 200, 30, BACKGROUND);
                LCD_DrawString(20, 190, "Invalid time format!");

                // Clear buffer for retry
                memset(key_buffer, 0, sizeof(key_buffer));
                current_key_index = 0;
            }
        }*/
    	if (current_mode == MODE_TIME_INPUT && current_key_index > 0) {
    	    uint16_t time_value = atoi(key_buffer);
    	    uint8_t hours = time_value / 100;
    	    uint8_t minutes = time_value % 100;

    	    if (hours < 24 && minutes < 60) {
    	        // ?   RTC ?   ????????????? ?  ?
    	        RTC_TimeTypeDef sTime = {0};
    	        sTime.Hours   = hours;
    	        sTime.Minutes = minutes;
    	        sTime.Seconds = 0;

    	        if (HAL_RTC_SetTime(&hrtc, &sTime, RTC_FORMAT_BIN) != HAL_OK) {
    	            Error_Handler();  // ?  ?   ?  ?  ?   메시 ????????????? 출력
    	        }

    	        // (?  ? ?  ?  ) ?  짜도 기본?   ????????????? ?    ????????????? ?  ?  ?  ?   ?  간이 반영?
    	        RTC_DateTypeDef sDate = {0};
    	        sDate.WeekDay = RTC_WEEKDAY_MONDAY;
    	        sDate.Month   = RTC_MONTH_JANUARY;
    	        sDate.Date    = 1;
    	        sDate.Year    = 24;  // 2024?
    	        HAL_RTC_SetDate(&hrtc, &sDate, RTC_FORMAT_BIN);

    	        // ?   ?   ????????????? 출력
    	        LCD_Clear(20, 190, 200, 30, BACKGROUND);
    	        char time_msg[32];
    	        sprintf(time_msg, "RTC Set: %02d:%02d:%02d", hours, minutes, 0);
    	        LCD_DrawString(20, 190, time_msg);

    	        // 버퍼 초기?    ????????????? ?  ?   �???? ?
    	        memset(key_buffer, 0, sizeof(key_buffer));
    	        current_key_index = 0;
    	        HAL_Delay(1500);
    	        current_mode = MODE_NONE;
    	        active_function = 0;
    	        display_mode = DISPLAY_SETTINGS;
    	        show_dispense_settings();
    	    } else {
    	        // ?   ????????????? ?  ?   ?   ????????????? 처리
    	        LCD_Clear(20, 190, 200, 30, BACKGROUND);
    	        LCD_DrawString(20, 190, "Invalid time format!");
    	        memset(key_buffer, 0, sizeof(key_buffer));
    	        current_key_index = 0;
    	    }
    	}
        // Corrected code to calculate food amount by dividing RED by calorie density
        else if (current_mode == MODE_WEIGHT_INPUT && current_key_index > 0) {
        	food_amount_ideal = FoodWeightForDog(food_amount_ideal);
            // Set dispense speed based on dog size
            dispense_speed = (dog_size == DOG_SIZE_SMALL) ? DISPENSE_SPEED_SMALL :
                            (dog_size == DOG_SIZE_MEDIUM) ? DISPENSE_SPEED_MEDIUM :
                                                            DISPENSE_SPEED_LARGE;

            // Display results
            LCD_Clear(20, 240, 200, 70, BACKGROUND);
            char dog_msg[32];

            if (dog_size == DOG_SIZE_SMALL) {
                sprintf(dog_msg, "Small dog (%dkg)", dog_weight);
            }
            else if (dog_size == DOG_SIZE_MEDIUM) {
                sprintf(dog_msg, "Medium dog (%dkg)", dog_weight);
            }
            else {
                sprintf(dog_msg, "Large dog (%dkg)", dog_weight);
            }

            // Display dog classification
            LCD_DrawString(20, 240, dog_msg);

            // Display food amount (final amount after dividing RED by calorie density)
            char food_msg[32];
            sprintf(food_msg, "Food: %dg (Speed: %d)", food_amount_ideal, dispense_speed);
            LCD_DrawString(20, 270, food_msg);

            // Clear buffer for next input
            memset(key_buffer, 0, sizeof(key_buffer));
            current_key_index = 0;

            // Wait a moment then return to main menu
            HAL_Delay(3000); // Increased to allow more time to read results
            current_mode = MODE_NONE;
            active_function = 0; // Reset active function flag
            display_mode = DISPLAY_SETTINGS;
            show_dispense_settings();
        }

    }

    // Handle numeric input for each mode (only for TIME_INPUT and WEIGHT_INPUT)
    if (key >= '0' && key <= '9') {
        if (current_mode == MODE_TIME_INPUT) {
            // For time input, max 4 digits (HHMM format)
            if (current_key_index < 4) {
                key_buffer[current_key_index++] = key;
                key_buffer[current_key_index] = '\0';

                // Update display with current input
                LCD_Clear(20, 150, 200, 30, BACKGROUND);

                // Format display nicely if we have 3 or 4 digits
                if (current_key_index >= 3) {
                    char formatted_time[10];
                    strncpy(formatted_time, key_buffer, 2);
                    formatted_time[2] = ':';
                    strncpy(formatted_time + 3, key_buffer + 2, current_key_index - 2);
                    formatted_time[current_key_index + 1] = '\0';
                    LCD_DrawString(20, 150, formatted_time);
                }
                else {
                    LCD_DrawString(20, 150, key_buffer);
                }
            }
        }
        else if (current_mode == MODE_WEIGHT_INPUT) {
            // For weight input, max 3 digits (up to 999kg)
            if (current_key_index < 3) {
                key_buffer[current_key_index++] = key;
                key_buffer[current_key_index] = '\0';

                // Update display
                LCD_Clear(20, 150, 200, 30, BACKGROUND);
                LCD_DrawString(20, 150, key_buffer);
                LCD_DrawString(20 + current_key_index * 8, 150, " kg");
            }
        }
    }
}

void storage_level_low (food_level, water_level){
	if (-1<=food_level && food_level<20 && 20 <= water_level && water_level<=100){ 			// FOOD lack: GREEN   	//RESET is tuning led on

		HAL_GPIO_WritePin(GPIOB, GPIO_PIN_5, GPIO_PIN_SET);			//red
		HAL_GPIO_WritePin(GPIOB, GPIO_PIN_0, GPIO_PIN_RESET); 		//green
		HAL_GPIO_WritePin(GPIOB, GPIO_PIN_1, GPIO_PIN_SET); 		//blue
	}
	else if (-1<=water_level && water_level<20 && 20 <= food_level && food_level<=100){ 		// WATER lack: BLUE
		HAL_GPIO_WritePin(GPIOB, GPIO_PIN_5, GPIO_PIN_SET);			//red
		HAL_GPIO_WritePin(GPIOB, GPIO_PIN_0, GPIO_PIN_SET); 		//green
		HAL_GPIO_WritePin(GPIOB, GPIO_PIN_1, GPIO_PIN_RESET); 		//blue

	}
	else if (-1<=food_level && food_level<20 && -1<=water_level && water_level<20 ){ 		// FOOD & WATER lack: RED
		HAL_GPIO_WritePin(GPIOB, GPIO_PIN_5, GPIO_PIN_RESET);			//red
		HAL_GPIO_WritePin(GPIOB, GPIO_PIN_0, GPIO_PIN_SET); 		//green
		HAL_GPIO_WritePin(GPIOB, GPIO_PIN_1, GPIO_PIN_SET); 		//blue

	}
	else {
		HAL_GPIO_WritePin(GPIOB, GPIO_PIN_5, GPIO_PIN_SET);			//red
		HAL_GPIO_WritePin(GPIOB, GPIO_PIN_0, GPIO_PIN_SET); 		//green
		HAL_GPIO_WritePin(GPIOB, GPIO_PIN_1, GPIO_PIN_SET); 		//blue
	}
}

// Updated function to display both water and food levels in bar charts (read-only)
void displayFoodWaterLevel(void) {
    // Clear the screen
    LCD_Clear(0, 0, 240, 320, BACKGROUND);

    // Draw title
    LCD_DrawString(60, 20, "Storage Levels");

    // Constants for the water level bar
    const int FOOD_BAR_LEFT = 60;
    const int BAR_WIDTH = 40;
    const int BAR_HEIGHT = 200;
    const int BAR_TOP = 60;
    const int BAR_BOTTOM = BAR_TOP + BAR_HEIGHT;
    const int WATER_BAR_LEFT = FOOD_BAR_LEFT + BAR_WIDTH + 40; // 40 pixel gap between bars


    int water_container_usage = UltraSonic_Sensor_WATER();
	water_level=(container_height-water_container_usage-1)*100/container_height; //in %
	if (water_level < 0) water_level = 0;
	if (water_level > 100) water_level = 100;

    int food_container_usage = UltraSonic_Sensor_FOOD();
    food_level = (container_height-food_container_usage)*100/container_height; // in %
	if (food_level < 0) food_level = 0;
	if (food_level > 100) food_level = 100;

    // Container 1: Water Level
    // Draw the empty container
    LCD_DrawLine(FOOD_BAR_LEFT, BAR_TOP, FOOD_BAR_LEFT, BAR_BOTTOM, BLACK);
    LCD_DrawLine(FOOD_BAR_LEFT + BAR_WIDTH, BAR_TOP, FOOD_BAR_LEFT + BAR_WIDTH, BAR_BOTTOM, BLACK);
    LCD_DrawLine(FOOD_BAR_LEFT, BAR_BOTTOM, FOOD_BAR_LEFT + BAR_WIDTH, BAR_BOTTOM, BLACK);
    LCD_DrawLine(FOOD_BAR_LEFT, BAR_TOP, FOOD_BAR_LEFT + BAR_WIDTH, BAR_TOP, BLACK);

    // Label for water
    LCD_DrawString(FOOD_BAR_LEFT, BAR_TOP - 20, "Food");

    // Calculate fill height based on water level percentage
    int fill_height = (BAR_HEIGHT * water_level)/5*5/100; //numbers of pixel

    // Draw water level bar (filled area)
    if (fill_height > 0) {
        LCD_Clear(WATER_BAR_LEFT + 1, BAR_BOTTOM - fill_height, BAR_WIDTH - 1, fill_height, BLUE);
    }

    // Container 2: Water Level (positioned to the right of water level)

    // Draw the empty container for food
    LCD_DrawLine(WATER_BAR_LEFT, BAR_TOP, WATER_BAR_LEFT, BAR_BOTTOM, BLACK);
    LCD_DrawLine(WATER_BAR_LEFT + BAR_WIDTH, BAR_TOP, WATER_BAR_LEFT + BAR_WIDTH, BAR_BOTTOM, BLACK);
    LCD_DrawLine(WATER_BAR_LEFT, BAR_BOTTOM, WATER_BAR_LEFT + BAR_WIDTH, BAR_BOTTOM, BLACK);
    LCD_DrawLine(WATER_BAR_LEFT, BAR_TOP, WATER_BAR_LEFT + BAR_WIDTH, BAR_TOP, BLACK);

    // Label for food
    LCD_DrawString(WATER_BAR_LEFT, BAR_TOP - 20, "Water");

    // Calculate fill height based on food level percentage
    int food_fill_height = (BAR_HEIGHT * food_level)/5*5 / 100;

    // Draw food level bar (filled area)
    if (food_fill_height > 0) {
        LCD_Clear(FOOD_BAR_LEFT + 1, BAR_BOTTOM - food_fill_height, BAR_WIDTH - 1, food_fill_height, GREEN);
    }

    // Draw percentage markers (on the sides of both containers)
    for (int i = 0; i <= 10; i++) {
        int y = BAR_BOTTOM - (i * BAR_HEIGHT / 10);

        // Food level markers (left side)
        LCD_DrawLine(FOOD_BAR_LEFT - 5, y, FOOD_BAR_LEFT, y, BLACK);

        // Water level markers (right side)
        LCD_DrawLine(WATER_BAR_LEFT + BAR_WIDTH, y, WATER_BAR_LEFT + BAR_WIDTH + 5, y, BLACK);

        // Only draw percentage labels on one side
        if (i % 2 == 0) { // Draw every other marker to avoid crowding
            char label[5];
            sprintf(label, "%d%%", i * 10);
            LCD_DrawSmallString(FOOD_BAR_LEFT - 25, y - 4, label);
        }
    }

    // Display current levels as text
    if (water_level <=0){

	LCD_DrawSmallString(WATER_BAR_LEFT - 20, BAR_BOTTOM + 20, "Water: 0%");
    }
    else{
    char water_text[20];
    sprintf(water_text, "Water: %d%%", water_level);
    LCD_DrawSmallString(WATER_BAR_LEFT - 20, BAR_BOTTOM + 20, water_text);
    }

    if (food_level <=0){

        LCD_DrawSmallString(FOOD_BAR_LEFT - 20, BAR_BOTTOM + 20, "Food: 0%");
    }
    else{
        char food_text[20];
        sprintf(food_text, "Food: %d%%", food_level);
        LCD_DrawSmallString(FOOD_BAR_LEFT - 20, BAR_BOTTOM + 20, food_text);
    }


    storage_level_low (food_level, water_level);
    // Instructions
    LCD_DrawSmallString(0, 290, "Press * to return to main menu");
}

// Updated displayCurrentTime function to ensure time updates continuously
void displayCurrentTime(void) {
	  HAL_RTC_GetTime(&hrtc, &sTime, RTC_FORMAT_BIN);
	  sprintf(time, "%02d.%02d.%02d", sTime.Hours, sTime.Minutes, sTime.Seconds);
	  LCD_DrawSmallString(170,310,time);
    /*static uint8_t last_second = 0xFF;

    // Only update the display when the second changes
    if (current_second != last_second) {
        last_second = current_second;

        // Clear the time display area (only when needed)
        LCD_Clear(170, 310, 70, 10, BACKGROUND);

        // Format time as HH:MM:SS
        snprintf(time_buffer, sizeof(time_buffer), "%02d:%02d:%02d",
                 current_hour, current_minute, current_second);

        // Display time in bottom-right corner
        LCD_DrawSmallString(170, 310, time_buffer);
    }*/
}

// Updated show_dispense_settings function to only display food amount
void show_dispense_settings(void) {
    // Clear the screen once
	storage_level_low (food_level, water_level);
    LCD_Clear(0, 0, 240, 320, BACKGROUND);

    // Display title
    LCD_DrawString(50, 30, "Smart Pet Feeder");

    // Show main menu options
    LCD_DrawSmallString(20, 60, "Press:");
    LCD_DrawSmallString(20, 80, "A: Display Storage Levels");
    LCD_DrawSmallString(20, 100, "B: Set Time");
    LCD_DrawSmallString(20, 120, "C: Set Dog Weight");
    LCD_DrawSmallString(20, 140, "D: Delete Input");
    LCD_DrawSmallString(20, 160, "* : Return to Main Menu");

    // Display static values that don't need to be refreshed constantly

    float water_container_usage = UltraSonic_Sensor_WATER();
    float food_container_usage = UltraSonic_Sensor_FOOD();
	water_level=(container_height-water_container_usage)*100/container_height;

//	char water_str[20];
    //snprintf(water_str, sizeof(water_str), "Water Level: %d%%", water_level);
    //LCD_DrawString(20, 210, water_str);

    //char food_str[20];
    //snprintf(food_str, sizeof(food_str), "Food Level: %d%%", food_level);
    //LCD_DrawString(20, 230, food_str);

    if (dog_weight > 0) {
        // Display dog information without RED value
        char weight_str[30];
        snprintf(weight_str, sizeof(weight_str), "Dog Weight: %dkg", dog_weight);
        LCD_DrawString(20, 190, weight_str);

        char type_str[30];
        if (dog_weight < 2) {
            snprintf(type_str, sizeof(type_str), "Type: Small Dog");
        } else if (dog_weight <= 45) {
            snprintf(type_str, sizeof(type_str), "Type: Medium Dog");
        } else {
            snprintf(type_str, sizeof(type_str), "Type: Large Dog");
        }
        LCD_DrawString(20, 210, type_str);


      /*  if (food_amount_ideal==99999){return;
                }
        else*/ if(food_amount_ideal!=211){
			char dispense_str[30];
			snprintf(dispense_str, sizeof(dispense_str), "Ideal Food Amount: %dg", food_amount_ideal);
			LCD_DrawString(20, 230, dispense_str);

			if (food_amount_ideal%50==0){
				char dispense_str_new[30];
				snprintf(dispense_str_new, sizeof(dispense_str_new), "Actual Food Amount: %dg", food_amount_ideal);
				LCD_DrawString(20, 250, dispense_str_new);
			}
			else{
				food_amount=food_amount_ideal/50*50+50;
				char dispense_str_new[30];
				snprintf(dispense_str_new, sizeof(dispense_str_new), "Actual Food Amount: %dg", food_amount);
				LCD_DrawString(20, 250, dispense_str_new);
			}
        }




    }

    // Only display keypad prompt if there's an active function
    if (active_function > 0) {
        displayKeypadPrompt();
    }
}

/*// Helper function to update dispense times based on first time and delay
void updateDispenseTimes(void) {
    // Calculate the second and third dispense times based on the first time and delay
    for (int i = 1; i < 3; i++) {
        uint16_t prev_time = dispense_time[i-1];
        uint8_t prev_hour = prev_time / 100;
        uint8_t prev_minute = prev_time % 100;

        // Calculate new time based on delay
        uint16_t delay_hours = dispense_delay / 60;
        uint16_t delay_minutes = dispense_delay % 60;

        uint8_t new_hour = prev_hour + delay_hours;
        uint8_t new_minute = prev_minute + delay_minutes;

        // Handle minute overflow
        if (new_minute >= 60) {
            new_minute -= 60;
            new_hour += 1;
        }

        // Handle hour overflow (24-hour format)
        if (new_hour >= 24) {
            new_hour -= 24;
        }

        // Set the new time
        dispense_time[i] = (new_hour * 100) + new_minute;
    }
}*/

/*void updateTimeDisplay(void) {
    static uint8_t last_settings_second = 0xFF;

    // Only update if we're in the settings screen and the time has changed
    if (display_mode == DISPLAY_SETTINGS && current_second != last_settings_second) {
        last_settings_second = current_second;

        // Clear only the time area
        LCD_Clear(20, 190, 190, 15, BACKGROUND);

        // Refresh the time display
        char time_str[30];
        snprintf(time_str, sizeof(time_str), "Current Time: %02d:%02d:%02d",
                 current_hour, current_minute, current_second);
        LCD_DrawString(20, 190, time_str);
    }

    // Update the corner time display (which has its own change detection)
    displayCurrentTime();
}*/

// Function to display the appropriate prompt for the current function
void displayKeypadPrompt(void) {
    LCD_Clear(40, 280, 160, 20, BACKGROUND);

    if (active_function == 1) {
        LCD_DrawSmallString(40, 280, "Enter time (HHMM):");
    }
    else if (active_function == 2) {
        LCD_DrawSmallString(40, 280, "Enter delay (min):");
    }
    else if (active_function == 3) {
        LCD_DrawSmallString(40, 280, "Enter amount (g):");
    }
    else if (active_function == 4) {
        LCD_DrawSmallString(40, 280, "Enter weight (kg):");
    }
    // When active_function is 0, nothing will be displayed
}

// Fixed version of checkDispenseTime to avoid buffer overflow
int checkDispenseTime(leftoverstate) {
    // Calculate current time in HHMM format
    RTC_TimeTypeDef time;
    RTC_DateTypeDef date;
    HAL_RTC_GetTime(&hrtc, &time, RTC_FORMAT_BIN);
    current_hour   = time.Hours;
    current_minute = time.Minutes;
    current_second = time.Seconds;

    uint16_t current_dispense_time;
    // Check each dispense time
    for (int i = 0; i < 3; i++) {
        uint16_t now_minutes = current_hour *100 + current_minute;

        if (now_minutes ==  dispense_time[i]) {
            // It's time to dispense food!
          	current_dispense_time = dispense_time[i];


        	if (current_second==2)
        	{
        		leftoverstate=0;
        	}


            //NEMA working! (Dispensing food)
        	if (current_second == 6)
        	{
        	    int x = (food_amount + 49) / 50;  // 올림 처리로 정확한 횟수 계산

        	    while (x > 0) {
        	        step(50, 1, 2000); // 왼쪽으로 90도 회전
        	        HAL_Delay(1000);
        	        x--;
        	        if (x <= 0) break;

        	        step(50, 0, 2000); // 오른쪽으로 90도 회전
        	        HAL_Delay(1000);
        	        x--;
        	    }
        	}

            if (current_second==5){

			  __HAL_TIM_SET_COMPARE(&htim8, TIM_CHANNEL_1, 2500);
			  //debug LCD_DrawString(100, 100, "55");
            }
            if (current_second==30){
			  //__HAL_TIM_SET_COMPARE(&htim8, TIM_CHANNEL_1, 2500);
			  //debug LCD_DrawString(100, 100, "22");
            }

        }


        if (now_minutes > current_dispense_time){

        	//debug if (leftoverstate){LCD_Clear(10, 10, 40, 20, BLACK); }

        	if(leftoverstate==0){
        	int dispense_time_number =  current_dispense_time;
            leftoverstate = checkWeightStability(current_dispense_time, now_minutes);
            //debug if (leftoverstate){LCD_Clear(0, 0, 40, 20, BLUE); }
        	}
        }
    }
    return leftoverstate;
}


// Initialize the app with a main menu
void showMainMenu(void) {
    LCD_Clear(0, 0, 240, 320, BACKGROUND);
    LCD_DrawString(110, 30, "ASMR");

    // Main menu options
    LCD_DrawSmallString(20, 60, "Press:");
    LCD_DrawString(20, 90, "A: Display Storage Levels");
    LCD_DrawString(20, 120, "B: Set Time");
    LCD_DrawString(20, 150, "C: Set Dog Weight");
    LCD_DrawString(20, 180, "D: Delete Input");
    LCD_DrawString(20, 210, "* : Return to Main Menu");

    // Display current time status if time is set
    char time_str[30];
    if (time_has_been_set) {
        snprintf(time_str, sizeof(time_str), "Current Time: %02d:%02d:%02d",
                 current_hour, current_minute, current_second);
    } else {
        snprintf(time_str, sizeof(time_str), "Time not set (00:00:00)");
    }
    LCD_DrawString(20, 240, time_str);

    // Set initial values

    current_mode = MODE_NONE;
}


/* USER CODE END 0 */

/**
  * @brief  The application entry point.
  * @retval int
  */
int main(void)
{
  /* USER CODE BEGIN 1 */

  /* USER CODE END 1 */

  /* MCU Configuration--------------------------------------------------------*/

  /* Reset of all peripherals, Initializes the Flash interface and the Systick. */
  HAL_Init();

  /* USER CODE BEGIN Init */
  MX_GPIO_Init();
  /* USER CODE END Init */

  /* Configure the system clock */
  SystemClock_Config();

  /* USER CODE BEGIN SysInit */

  /* USER CODE END SysInit */

  /* Initialize all configured peripherals */
  MX_GPIO_Init();
  MX_FSMC_Init();
  MX_TIM1_Init();
  MX_TIM2_Init();
  MX_TIM8_Init();
  MX_RTC_Init();
  MX_USART1_UART_Init();
  /* USER CODE BEGIN 2 */
  SystemCoreClockUpdate();
  SysTick_Config(SystemCoreClock / 1000);
  LCD_INIT();
  HAL_TIM_PWM_Start(&htim8, TIM_CHANNEL_1);//servo

  // Initialize time variables to 00:00:00
  current_hour = 0;
  current_minute = 0;
  current_second = 0;
  time_has_been_set = 0; // Time not set yet
  active_function = 0;   // Initialize active_function to 0 - ADD THIS LINE

  // Sample data
  addFoodRecord(100, 50, 5);
  addFoodRecord(110, 50, 4);
  addFoodRecord(120, 50, 3);




  // Set initial display mode to show settings screen
  display_mode = DISPLAY_SETTINGS;

  // Display initial settings screen on startup

  showMainMenu();

  HAL_TIM_Base_Start(&htim1);
  HAL_GPIO_WritePin(SCK_PORT, SCK_PIN, GPIO_PIN_SET); //(load)
  HAL_Delay(10);										//(load)
  HAL_GPIO_WritePin(SCK_PORT, SCK_PIN, GPIO_PIN_RESET);//(load)
  HAL_Delay(10);										//(load)
  HAL_GPIO_WritePin(TRIG_PORT_WATER, TRIG_PIN_WATER, GPIO_PIN_RESET);  // (us sensor) pull the TRIG pin low
  HAL_GPIO_WritePin(TRIG_PORT_FOOD, TRIG_PIN_FOOD, GPIO_PIN_RESET);
  uint32_t lastUpdate = 0;
  int displaymode = 0; 	//display setting
  __HAL_TIM_SET_COMPARE(&htim8, TIM_CHANNEL_1, 500);//food bowl initial position


  //turn off LED
	HAL_GPIO_WritePin(GPIOB, GPIO_PIN_5, GPIO_PIN_SET);			//red
	HAL_GPIO_WritePin(GPIOB, GPIO_PIN_0, GPIO_PIN_SET); 		//green
	HAL_GPIO_WritePin(GPIOB, GPIO_PIN_1, GPIO_PIN_SET); 		//blue
	displayFoodWaterLevel();
	  LCD_Clear(0, 0, 240, 320, BACKGROUND);
	  HAL_UART_Receive_IT(&huart1, &rxData, 1);

  /* USER CODE END 2 */

  /* Infinite loop */
  /* USER CODE BEGIN WHILE */
  while (1)
  {
	    // Check for midnight update
	    //checkForMidnightUpdate();

	    static uint8_t last_display_mode = 255; // Invalid initial value to force first draw
	    uint32_t current_tick = HAL_GetTick();

	    // Check if it's time to dispense food
	    leftoverstate=checkDispenseTime(leftoverstate);
		char leftoverstring[30];
		snprintf(leftoverstring, sizeof(leftoverstring), "leftover_state: %dg", leftoverstate);
        //LCD_DrawString(0, 240, leftoverstring);

	    //Check Storage level
	    storage_level_low (food_level, water_level);


	    // K1 button with improved state detection - toggle between graphs
	    if (HAL_GPIO_ReadPin(GPIOA, GPIO_PIN_0) == GPIO_PIN_SET) {
	    	displaymode++;

	    	if (displaymode%3==1){
		        LCD_Clear(0, 0, 240, 320, BACKGROUND);
    	        HAL_Delay(5);
	    		display_mode = DISPLAY_GRAPH_1;
	    		last_display_mode = 255;
	    	}
	    	else if (displaymode%3==2){
		        LCD_Clear(0, 0, 240, 320, BACKGROUND);
    	        HAL_Delay(5);
	    		display_mode = DISPLAY_GRAPH_2;
	    		last_display_mode = 255;
	    	}
	    	else if (displaymode%3==0){
		        LCD_Clear(0, 0, 240, 320, BACKGROUND);
    	        HAL_Delay(5);
		        //current_mode = MODE_NONE;
		        //active_function = 0; // Reset active function when returning to main menu - ADD THIS LINE
		        display_mode = DISPLAY_SETTINGS;
		        LCD_Clear(0, 0, 240, 320, BACKGROUND);
		        last_display_mode = 255;
	    	}
	    }

	    // Read keypad with debouncing
	    static uint32_t last_keypad_check = 0;
	    if (current_tick - last_keypad_check > 250) { // Check every 250ms
	      last_keypad_check = current_tick;

	      char key = readKeypad();
	      if (key != 0) {
	        // Process the keypad input
	        processKeypadInput(key);
	      }
	    }

	    // Display content based on current mode
	    // Only redraw if the display mode has changed
	    if (display_mode != last_display_mode) {
	      switch (display_mode) {
	        case DISPLAY_SETTINGS:
	          show_dispense_settings();
	          break;

	        case DISPLAY_GRAPH_1:
	          draw_graph_1();
	          break;

	        case DISPLAY_GRAPH_2:
	          draw_graph_2();
	          break;

	        default:
	          // Should never happen
	          break;
	      }

	      last_display_mode = display_mode;
	    }

	    // Always show the current time
	    displayCurrentTime();

	    // Update the time
	    //updateTime();
	    if (HAL_GetTick() - lastUpdate > 100) {
	        weigh();
	        weigh_RIGHT();
	        lastUpdate = HAL_GetTick();
	    }


    /* USER CODE END WHILE */

    /* USER CODE BEGIN 3 */
  }
  /* USER CODE END 3 */
}

/**
  * @brief System Clock Configuration
  * @retval None
  */
void SystemClock_Config(void)
{
  RCC_OscInitTypeDef RCC_OscInitStruct = {0};
  RCC_ClkInitTypeDef RCC_ClkInitStruct = {0};
  RCC_PeriphCLKInitTypeDef PeriphClkInit = {0};

  /** Initializes the RCC Oscillators according to the specified parameters
  * in the RCC_OscInitTypeDef structure.
  */
  RCC_OscInitStruct.OscillatorType = RCC_OSCILLATORTYPE_LSI|RCC_OSCILLATORTYPE_HSE;
  RCC_OscInitStruct.HSEState = RCC_HSE_ON;
  RCC_OscInitStruct.HSEPredivValue = RCC_HSE_PREDIV_DIV1;
  RCC_OscInitStruct.HSIState = RCC_HSI_ON;
  RCC_OscInitStruct.LSIState = RCC_LSI_ON;
  RCC_OscInitStruct.PLL.PLLState = RCC_PLL_ON;
  RCC_OscInitStruct.PLL.PLLSource = RCC_PLLSOURCE_HSE;
  RCC_OscInitStruct.PLL.PLLMUL = RCC_PLL_MUL9;
  if (HAL_RCC_OscConfig(&RCC_OscInitStruct) != HAL_OK)
  {
    Error_Handler();
  }

  /** Initializes the CPU, AHB and APB buses clocks
  */
  RCC_ClkInitStruct.ClockType = RCC_CLOCKTYPE_HCLK|RCC_CLOCKTYPE_SYSCLK
                              |RCC_CLOCKTYPE_PCLK1|RCC_CLOCKTYPE_PCLK2;
  RCC_ClkInitStruct.SYSCLKSource = RCC_SYSCLKSOURCE_PLLCLK;
  RCC_ClkInitStruct.AHBCLKDivider = RCC_SYSCLK_DIV1;
  RCC_ClkInitStruct.APB1CLKDivider = RCC_HCLK_DIV2;
  RCC_ClkInitStruct.APB2CLKDivider = RCC_HCLK_DIV1;

  if (HAL_RCC_ClockConfig(&RCC_ClkInitStruct, FLASH_LATENCY_2) != HAL_OK)
  {
    Error_Handler();
  }
  PeriphClkInit.PeriphClockSelection = RCC_PERIPHCLK_RTC;
  PeriphClkInit.RTCClockSelection = RCC_RTCCLKSOURCE_LSI;
  if (HAL_RCCEx_PeriphCLKConfig(&PeriphClkInit) != HAL_OK)
  {
    Error_Handler();
  }
}

/**
  * @brief RTC Initialization Function
  * @param None
  * @retval None
  */
static void MX_RTC_Init(void)
{

  /* USER CODE BEGIN RTC_Init 0 */

  /* USER CODE END RTC_Init 0 */

  RTC_TimeTypeDef sTime = {0};
  RTC_DateTypeDef DateToUpdate = {0};

  /* USER CODE BEGIN RTC_Init 1 */

  /* USER CODE END RTC_Init 1 */

  /** Initialize RTC Only
  */
  hrtc.Instance = RTC;
  hrtc.Init.AsynchPrediv = RTC_AUTO_1_SECOND;
  hrtc.Init.OutPut = RTC_OUTPUTSOURCE_ALARM;
  if (HAL_RTC_Init(&hrtc) != HAL_OK)
  {
    Error_Handler();
  }

  /* USER CODE BEGIN Check_RTC_BKUP */

  /* USER CODE END Check_RTC_BKUP */

  /** Initialize RTC and set the Time and Date
  */
  sTime.Hours = 0x0;
  sTime.Minutes = 0x0;
  sTime.Seconds = 0x0;

  if (HAL_RTC_SetTime(&hrtc, &sTime, RTC_FORMAT_BCD) != HAL_OK)
  {
    Error_Handler();
  }
  DateToUpdate.WeekDay = RTC_WEEKDAY_MONDAY;
  DateToUpdate.Month = RTC_MONTH_JANUARY;
  DateToUpdate.Date = 0x1;
  DateToUpdate.Year = 0x0;

  if (HAL_RTC_SetDate(&hrtc, &DateToUpdate, RTC_FORMAT_BCD) != HAL_OK)
  {
    Error_Handler();
  }
  /* USER CODE BEGIN RTC_Init 2 */

  /* USER CODE END RTC_Init 2 */

}

/**
  * @brief TIM1 Initialization Function
  * @param None
  * @retval None
  */
static void MX_TIM1_Init(void)
{

  /* USER CODE BEGIN TIM1_Init 0 */

  /* USER CODE END TIM1_Init 0 */

  TIM_ClockConfigTypeDef sClockSourceConfig = {0};
  TIM_MasterConfigTypeDef sMasterConfig = {0};

  /* USER CODE BEGIN TIM1_Init 1 */

  /* USER CODE END TIM1_Init 1 */
  htim1.Instance = TIM1;
  htim1.Init.Prescaler = 71;
  htim1.Init.CounterMode = TIM_COUNTERMODE_UP;
  htim1.Init.Period = 65535;
  htim1.Init.ClockDivision = TIM_CLOCKDIVISION_DIV1;
  htim1.Init.RepetitionCounter = 0;
  htim1.Init.AutoReloadPreload = TIM_AUTORELOAD_PRELOAD_DISABLE;
  if (HAL_TIM_Base_Init(&htim1) != HAL_OK)
  {
    Error_Handler();
  }
  sClockSourceConfig.ClockSource = TIM_CLOCKSOURCE_INTERNAL;
  if (HAL_TIM_ConfigClockSource(&htim1, &sClockSourceConfig) != HAL_OK)
  {
    Error_Handler();
  }
  sMasterConfig.MasterOutputTrigger = TIM_TRGO_RESET;
  sMasterConfig.MasterSlaveMode = TIM_MASTERSLAVEMODE_DISABLE;
  if (HAL_TIMEx_MasterConfigSynchronization(&htim1, &sMasterConfig) != HAL_OK)
  {
    Error_Handler();
  }
  /* USER CODE BEGIN TIM1_Init 2 */

  /* USER CODE END TIM1_Init 2 */

}

/**
  * @brief TIM2 Initialization Function
  * @param None
  * @retval None
  */
static void MX_TIM2_Init(void)
{

  /* USER CODE BEGIN TIM2_Init 0 */

  /* USER CODE END TIM2_Init 0 */

  TIM_ClockConfigTypeDef sClockSourceConfig = {0};
  TIM_MasterConfigTypeDef sMasterConfig = {0};

  /* USER CODE BEGIN TIM2_Init 1 */

  /* USER CODE END TIM2_Init 1 */
  htim2.Instance = TIM2;
  htim2.Init.Prescaler = 79;
  htim2.Init.CounterMode = TIM_COUNTERMODE_UP;
  htim2.Init.Period = 2000;
  htim2.Init.ClockDivision = TIM_CLOCKDIVISION_DIV1;
  htim2.Init.AutoReloadPreload = TIM_AUTORELOAD_PRELOAD_DISABLE;
  if (HAL_TIM_Base_Init(&htim2) != HAL_OK)
  {
    Error_Handler();
  }
  sClockSourceConfig.ClockSource = TIM_CLOCKSOURCE_INTERNAL;
  if (HAL_TIM_ConfigClockSource(&htim2, &sClockSourceConfig) != HAL_OK)
  {
    Error_Handler();
  }
  sMasterConfig.MasterOutputTrigger = TIM_TRGO_RESET;
  sMasterConfig.MasterSlaveMode = TIM_MASTERSLAVEMODE_DISABLE;
  if (HAL_TIMEx_MasterConfigSynchronization(&htim2, &sMasterConfig) != HAL_OK)
  {
    Error_Handler();
  }
  /* USER CODE BEGIN TIM2_Init 2 */

  /* USER CODE END TIM2_Init 2 */

}

/**
  * @brief TIM8 Initialization Function
  * @param None
  * @retval None
  */
static void MX_TIM8_Init(void)
{

  /* USER CODE BEGIN TIM8_Init 0 */

  /* USER CODE END TIM8_Init 0 */

  TIM_MasterConfigTypeDef sMasterConfig = {0};
  TIM_OC_InitTypeDef sConfigOC = {0};
  TIM_BreakDeadTimeConfigTypeDef sBreakDeadTimeConfig = {0};

  /* USER CODE BEGIN TIM8_Init 1 */

  /* USER CODE END TIM8_Init 1 */
  htim8.Instance = TIM8;
  htim8.Init.Prescaler = 71;
  htim8.Init.CounterMode = TIM_COUNTERMODE_UP;
  htim8.Init.Period = 19999;
  htim8.Init.ClockDivision = TIM_CLOCKDIVISION_DIV1;
  htim8.Init.RepetitionCounter = 0;
  htim8.Init.AutoReloadPreload = TIM_AUTORELOAD_PRELOAD_DISABLE;
  if (HAL_TIM_PWM_Init(&htim8) != HAL_OK)
  {
    Error_Handler();
  }
  sMasterConfig.MasterOutputTrigger = TIM_TRGO_RESET;
  sMasterConfig.MasterSlaveMode = TIM_MASTERSLAVEMODE_DISABLE;
  if (HAL_TIMEx_MasterConfigSynchronization(&htim8, &sMasterConfig) != HAL_OK)
  {
    Error_Handler();
  }
  sConfigOC.OCMode = TIM_OCMODE_PWM1;
  sConfigOC.Pulse = 0;
  sConfigOC.OCPolarity = TIM_OCPOLARITY_HIGH;
  sConfigOC.OCNPolarity = TIM_OCNPOLARITY_HIGH;
  sConfigOC.OCFastMode = TIM_OCFAST_DISABLE;
  sConfigOC.OCIdleState = TIM_OCIDLESTATE_RESET;
  sConfigOC.OCNIdleState = TIM_OCNIDLESTATE_RESET;
  if (HAL_TIM_PWM_ConfigChannel(&htim8, &sConfigOC, TIM_CHANNEL_1) != HAL_OK)
  {
    Error_Handler();
  }
  sBreakDeadTimeConfig.OffStateRunMode = TIM_OSSR_DISABLE;
  sBreakDeadTimeConfig.OffStateIDLEMode = TIM_OSSI_DISABLE;
  sBreakDeadTimeConfig.LockLevel = TIM_LOCKLEVEL_OFF;
  sBreakDeadTimeConfig.DeadTime = 0;
  sBreakDeadTimeConfig.BreakState = TIM_BREAK_DISABLE;
  sBreakDeadTimeConfig.BreakPolarity = TIM_BREAKPOLARITY_HIGH;
  sBreakDeadTimeConfig.AutomaticOutput = TIM_AUTOMATICOUTPUT_DISABLE;
  if (HAL_TIMEx_ConfigBreakDeadTime(&htim8, &sBreakDeadTimeConfig) != HAL_OK)
  {
    Error_Handler();
  }
  /* USER CODE BEGIN TIM8_Init 2 */

  /* USER CODE END TIM8_Init 2 */
  HAL_TIM_MspPostInit(&htim8);

}

/**
  * @brief USART1 Initialization Function
  * @param None
  * @retval None
  */
static void MX_USART1_UART_Init(void)
{

  /* USER CODE BEGIN USART1_Init 0 */

  /* USER CODE END USART1_Init 0 */

  /* USER CODE BEGIN USART1_Init 1 */

  /* USER CODE END USART1_Init 1 */
  huart1.Instance = USART1;
  huart1.Init.BaudRate = 9600;
  huart1.Init.WordLength = UART_WORDLENGTH_8B;
  huart1.Init.StopBits = UART_STOPBITS_1;
  huart1.Init.Parity = UART_PARITY_NONE;
  huart1.Init.Mode = UART_MODE_TX_RX;
  huart1.Init.HwFlowCtl = UART_HWCONTROL_NONE;
  huart1.Init.OverSampling = UART_OVERSAMPLING_16;
  if (HAL_UART_Init(&huart1) != HAL_OK)
  {
    Error_Handler();
  }
  /* USER CODE BEGIN USART1_Init 2 */

  /* USER CODE END USART1_Init 2 */

}

/**
  * @brief GPIO Initialization Function
  * @param None
  * @retval None
  */
static void MX_GPIO_Init(void)
{
  GPIO_InitTypeDef GPIO_InitStruct = {0};

  /* GPIO Ports Clock Enable */
  __HAL_RCC_GPIOC_CLK_ENABLE();
  __HAL_RCC_GPIOA_CLK_ENABLE();
  __HAL_RCC_GPIOB_CLK_ENABLE();
  __HAL_RCC_GPIOE_CLK_ENABLE();
  __HAL_RCC_GPIOD_CLK_ENABLE();

  /*Configure GPIO pin Output Level */
  HAL_GPIO_WritePin(GPIOC, GPIO_PIN_3|GPIO_PIN_4, GPIO_PIN_SET);

  /*Configure GPIO pin Output Level */
  HAL_GPIO_WritePin(GPIOA, GPIO_PIN_6|GPIO_PIN_7|GPIO_PIN_11|GPIO_PIN_12, GPIO_PIN_RESET);

  /*Configure GPIO pin Output Level */
  HAL_GPIO_WritePin(GPIOB, GPIO_PIN_0|GPIO_PIN_1|GPIO_PIN_5|GPIO_PIN_7, GPIO_PIN_RESET);

  /*Configure GPIO pin Output Level */
  HAL_GPIO_WritePin(GPIOB, GPIO_PIN_10|GPIO_PIN_11|GPIO_PIN_8|GPIO_PIN_9, GPIO_PIN_SET);

  /*Configure GPIO pin Output Level */
  HAL_GPIO_WritePin(GPIOD, GPIO_PIN_12, GPIO_PIN_RESET);

  /*Configure GPIO pin Output Level */
  HAL_GPIO_WritePin(GPIOC, GPIO_PIN_7|GPIO_PIN_8|GPIO_PIN_12, GPIO_PIN_RESET);

  /*Configure GPIO pin Output Level */
  HAL_GPIO_WritePin(GPIOD, GPIO_PIN_3, GPIO_PIN_SET);

  /*Configure GPIO pin Output Level */
  HAL_GPIO_WritePin(GPIOE, GPIO_PIN_1, GPIO_PIN_RESET);

  /*Configure GPIO pins : PC13 PC11 */
  GPIO_InitStruct.Pin = GPIO_PIN_13|GPIO_PIN_11;
  GPIO_InitStruct.Mode = GPIO_MODE_INPUT;
  GPIO_InitStruct.Pull = GPIO_NOPULL;
  HAL_GPIO_Init(GPIOC, &GPIO_InitStruct);

  /*Configure GPIO pins : PC3 PC4 */
  GPIO_InitStruct.Pin = GPIO_PIN_3|GPIO_PIN_4;
  GPIO_InitStruct.Mode = GPIO_MODE_OUTPUT_PP;
  GPIO_InitStruct.Pull = GPIO_NOPULL;
  GPIO_InitStruct.Speed = GPIO_SPEED_FREQ_HIGH;
  HAL_GPIO_Init(GPIOC, &GPIO_InitStruct);

  /*Configure GPIO pins : PA0 PA2 PA3 PA5 */
  GPIO_InitStruct.Pin = GPIO_PIN_0|GPIO_PIN_2|GPIO_PIN_3|GPIO_PIN_5;
  GPIO_InitStruct.Mode = GPIO_MODE_INPUT;
  GPIO_InitStruct.Pull = GPIO_NOPULL;
  HAL_GPIO_Init(GPIOA, &GPIO_InitStruct);

  /*Configure GPIO pin : PA4 */
  GPIO_InitStruct.Pin = GPIO_PIN_4;
  GPIO_InitStruct.Mode = GPIO_MODE_IT_RISING;
  GPIO_InitStruct.Pull = GPIO_NOPULL;
  HAL_GPIO_Init(GPIOA, &GPIO_InitStruct);

  /*Configure GPIO pin : PA6 */
  GPIO_InitStruct.Pin = GPIO_PIN_6;
  GPIO_InitStruct.Mode = GPIO_MODE_OUTPUT_PP;
  GPIO_InitStruct.Pull = GPIO_NOPULL;
  GPIO_InitStruct.Speed = GPIO_SPEED_FREQ_HIGH;
  HAL_GPIO_Init(GPIOA, &GPIO_InitStruct);

  /*Configure GPIO pins : PA7 PA11 PA12 */
  GPIO_InitStruct.Pin = GPIO_PIN_7|GPIO_PIN_11|GPIO_PIN_12;
  GPIO_InitStruct.Mode = GPIO_MODE_OUTPUT_PP;
  GPIO_InitStruct.Pull = GPIO_NOPULL;
  GPIO_InitStruct.Speed = GPIO_SPEED_FREQ_LOW;
  HAL_GPIO_Init(GPIOA, &GPIO_InitStruct);

  /*Configure GPIO pins : PB0 PB1 PB10 PB11
                           PB5 PB7 PB8 PB9 */
  GPIO_InitStruct.Pin = GPIO_PIN_0|GPIO_PIN_1|GPIO_PIN_10|GPIO_PIN_11
                          |GPIO_PIN_5|GPIO_PIN_7|GPIO_PIN_8|GPIO_PIN_9;
  GPIO_InitStruct.Mode = GPIO_MODE_OUTPUT_PP;
  GPIO_InitStruct.Pull = GPIO_NOPULL;
  GPIO_InitStruct.Speed = GPIO_SPEED_FREQ_LOW;
  HAL_GPIO_Init(GPIOB, &GPIO_InitStruct);

  /*Configure GPIO pins : PB12 PB13 PB14 PB15 */
  GPIO_InitStruct.Pin = GPIO_PIN_12|GPIO_PIN_13|GPIO_PIN_14|GPIO_PIN_15;
  GPIO_InitStruct.Mode = GPIO_MODE_INPUT;
  GPIO_InitStruct.Pull = GPIO_PULLDOWN;
  HAL_GPIO_Init(GPIOB, &GPIO_InitStruct);

  /*Configure GPIO pins : PD12 PD3 */
  GPIO_InitStruct.Pin = GPIO_PIN_12|GPIO_PIN_3;
  GPIO_InitStruct.Mode = GPIO_MODE_OUTPUT_PP;
  GPIO_InitStruct.Pull = GPIO_NOPULL;
  GPIO_InitStruct.Speed = GPIO_SPEED_FREQ_HIGH;
  HAL_GPIO_Init(GPIOD, &GPIO_InitStruct);

  /*Configure GPIO pins : PC7 PC8 PC12 */
  GPIO_InitStruct.Pin = GPIO_PIN_7|GPIO_PIN_8|GPIO_PIN_12;
  GPIO_InitStruct.Mode = GPIO_MODE_OUTPUT_PP;
  GPIO_InitStruct.Pull = GPIO_NOPULL;
  GPIO_InitStruct.Speed = GPIO_SPEED_FREQ_LOW;
  HAL_GPIO_Init(GPIOC, &GPIO_InitStruct);

  /*Configure GPIO pin : PD2 */
  GPIO_InitStruct.Pin = GPIO_PIN_2;
  GPIO_InitStruct.Mode = GPIO_MODE_IT_RISING;
  GPIO_InitStruct.Pull = GPIO_NOPULL;
  HAL_GPIO_Init(GPIOD, &GPIO_InitStruct);

  /*Configure GPIO pin : PB6 */
  GPIO_InitStruct.Pin = GPIO_PIN_6;
  GPIO_InitStruct.Mode = GPIO_MODE_INPUT;
  GPIO_InitStruct.Pull = GPIO_NOPULL;
  HAL_GPIO_Init(GPIOB, &GPIO_InitStruct);

  /*Configure GPIO pin : PE1 */
  GPIO_InitStruct.Pin = GPIO_PIN_1;
  GPIO_InitStruct.Mode = GPIO_MODE_OUTPUT_PP;
  GPIO_InitStruct.Pull = GPIO_NOPULL;
  GPIO_InitStruct.Speed = GPIO_SPEED_FREQ_HIGH;
  HAL_GPIO_Init(GPIOE, &GPIO_InitStruct);

  /* EXTI interrupt init*/
  HAL_NVIC_SetPriority(EXTI2_IRQn, 0, 0);
  HAL_NVIC_EnableIRQ(EXTI2_IRQn);

  HAL_NVIC_SetPriority(EXTI4_IRQn, 0, 0);
  HAL_NVIC_EnableIRQ(EXTI4_IRQn);

}

/* FSMC initialization function */
static void MX_FSMC_Init(void)
{

  /* USER CODE BEGIN FSMC_Init 0 */

  /* USER CODE END FSMC_Init 0 */

  FSMC_NORSRAM_TimingTypeDef Timing = {0};

  /* USER CODE BEGIN FSMC_Init 1 */

  /* USER CODE END FSMC_Init 1 */

  /** Perform the SRAM1 memory initialization sequence
  */
  hsram1.Instance = FSMC_NORSRAM_DEVICE;
  hsram1.Extended = FSMC_NORSRAM_EXTENDED_DEVICE;
  /* hsram1.Init */
  hsram1.Init.NSBank = FSMC_NORSRAM_BANK1;
  hsram1.Init.DataAddressMux = FSMC_DATA_ADDRESS_MUX_DISABLE;
  hsram1.Init.MemoryType = FSMC_MEMORY_TYPE_SRAM;
  hsram1.Init.MemoryDataWidth = FSMC_NORSRAM_MEM_BUS_WIDTH_16;
  hsram1.Init.BurstAccessMode = FSMC_BURST_ACCESS_MODE_DISABLE;
  hsram1.Init.WaitSignalPolarity = FSMC_WAIT_SIGNAL_POLARITY_LOW;
  hsram1.Init.WrapMode = FSMC_WRAP_MODE_DISABLE;
  hsram1.Init.WaitSignalActive = FSMC_WAIT_TIMING_BEFORE_WS;
  hsram1.Init.WriteOperation = FSMC_WRITE_OPERATION_ENABLE;
  hsram1.Init.WaitSignal = FSMC_WAIT_SIGNAL_DISABLE;
  hsram1.Init.ExtendedMode = FSMC_EXTENDED_MODE_DISABLE;
  hsram1.Init.AsynchronousWait = FSMC_ASYNCHRONOUS_WAIT_DISABLE;
  hsram1.Init.WriteBurst = FSMC_WRITE_BURST_DISABLE;
  /* Timing */
  Timing.AddressSetupTime = 15;
  Timing.AddressHoldTime = 15;
  Timing.DataSetupTime = 255;
  Timing.BusTurnAroundDuration = 15;
  Timing.CLKDivision = 16;
  Timing.DataLatency = 17;
  Timing.AccessMode = FSMC_ACCESS_MODE_A;
  /* ExtTiming */

  if (HAL_SRAM_Init(&hsram1, &Timing, NULL) != HAL_OK)
  {
    Error_Handler( );
  }

  /** Disconnect NADV
  */

  __HAL_AFIO_FSMCNADV_DISCONNECTED();

  /* USER CODE BEGIN FSMC_Init 2 */

  /* USER CODE END FSMC_Init 2 */
}

/* USER CODE BEGIN 4 */
void SendBluetoothMessage(const char* message)
{
  HAL_UART_Transmit(&huart1, (uint8_t*)message, strlen(message), 100);
}
void HAL_UART_RxCpltCallback(UART_HandleTypeDef *huart) { //BTBT
	if(huart -> Instance == USART1)
	{
		if(rxData == 49) //49 = '1'
		{
			int x;
			for(x=0; x<2; x=x+1)
				{
				  step_T(50, 1, 2000);
				  for (volatile uint32_t i = 0; i < 3000000; i++); 	//Wait 0.7 sec
				  step_T(50, 0, 2000);
				  for (volatile uint32_t i = 0; i < 3000000; i++); 	//Wait 0.7 sec
				}

			SendBluetoothMessage("Dispensing 1\r\n");
		}

		else if (rxData == 50)
		{
			SendBluetoothMessage("Dispensing 2\r\n");
            int x;

            for(x=0; x<4; x=x+1)
				{
				  step_T(50, 1, 2000);
				  for (volatile uint32_t i = 0; i < 3000000; i++); 	//Wait 0.7 sec
				  step_T(50, 0, 2000);
				  for (volatile uint32_t i = 0; i < 3000000; i++); 	//Wait 0.7 sec
				}


		}
		else if (rxData == 51)
		{
			SendBluetoothMessage("Food motor stablize\r\n");
            int x;

            for(x=0; x<1; x=x+1)
				{
				  step(10, 1, 2000);
				  for (volatile uint32_t i = 0; i < 30000; i++); 	//Wait 0.7 sec
				}
		}
		else if (rxData == 52) //4
		{
			  __HAL_TIM_SET_COMPARE(&htim8, TIM_CHANNEL_1, 500);

		}

		else if (rxData == 55) //4
		{
			  addFoodRecord(310, 154, 80);
		}


		HAL_UART_Receive_IT(&huart1, &rxData, 1);
	}



}
/* USER CODE END 4 */

/**
  * @brief  This function is executed in case of error occurrence.
  * @retval None
  */
void Error_Handler(void)
{
  /* USER CODE BEGIN Error_Handler_Debug */
  /* User can add his own implementation to report the HAL error return state */
  __disable_irq();
  while (1)
  {
  }
  /* USER CODE END Error_Handler_Debug */
}

#ifdef  USE_FULL_ASSERT
/**
  * @brief  Reports the name of the source file and the source line number
  *         where the assert_param error has occurred.
  * @param  file: pointer to the source file name
  * @param  line: assert_param error line source number
  * @retval None
  */
void assert_failed(uint8_t *file, uint32_t line)
{
  /* USER CODE BEGIN 6 */
  /* User can add his own implementation to report the file name and line number,
     ex: printf("Wrong parameters value: file %s on line %d\r\n", file, line) */
  /* USER CODE END 6 */
}
#endif /* USE_FULL_ASSERT */
